#include <stdio.h>
#include <stdlib.h>
#include "UI.h"
#include "DynamicArray.h"

// Вариант 11:
// Динамический массив
// Целые числа, строки
// Сортировка, map, where, Конкатенация

int main(){
    int ch;
    yourchoice();

}

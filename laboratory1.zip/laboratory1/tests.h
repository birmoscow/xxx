//
// Created by Илья Атмажитов on 29.03.2024.
//

#ifndef LABORATORY1_TESTS_H
#define LABORATORY1_TESTS_H



void test_init_vector();
void test_push_vector();
void test_sort_vector();
void test_concatenation();
void test_where();
void test_map();
void test_str_functions();

#endif //LABORATORY1_TESTS_H


//
// Created by Илья Атмажитов on 15.03.2024.
//

#ifndef LABORATORY1_MENU_H
#define LABORATORY1_MENU_H

// displayUI - функция, которая выводит меню.
void displayUI();

// yourchoice - функция, которая определяет ход работы программы.
void yourchoice();

#endif //LABORATORY1_MENU_H



